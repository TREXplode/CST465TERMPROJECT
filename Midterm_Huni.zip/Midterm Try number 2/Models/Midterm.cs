﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    public class MidtermQs
    {
        public List<TestQuestion> Tquestions { get; set; }
    }
}
